---
id: 477
title: Power up your terminal
date: 2017-08-27T19:24:49+08:00
author: shantanualshi
layout: revision
guid: http://blog.shantanualshi.com/2017/08/27/475-revision-v1/
permalink: /2017/08/27/475-revision-v1/
---
Have you heard about teletypewriters? Pre-Unix, time-sharing systems developed  terminals &#8211; teletypes or **ttys**,  that allowed you to issue commands to the computer over a serial link. These systems, albeit having lost their physical existence in the recent technology advancements, have their essence in your laptops (if you are a *nix user).

&nbsp;

&nbsp;

https://www.quora.com/How-do-I-understand-the-tmux-design-architecture-and-internals

https://unix.stackexchange.com/questions/117981/what-are-the-responsibilities-of-each-pseudo-terminal-pty-component-software