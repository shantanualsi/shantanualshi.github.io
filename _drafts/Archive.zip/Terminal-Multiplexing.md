---
id: 475
title: Terminal Multiplexing
date: 2017-08-27T19:27:56+08:00
author: shantanualshi
layout: post
guid: http://blog.shantanualshi.com/?p=475
permalink: /?p=475
categories:
  - Uncategorized
---
Have you heard about teletypewriters? Pre-Unix, time-sharing systems developed  terminals &#8211; teletypes or **ttys**,  that allowed you to issue commands to the computer over a serial link. These systems, albeit having lost their physical existence in the recent technology advancements, have their essence in your laptops (if you are a *nix user).

&nbsp;

&nbsp;

https://www.quora.com/How-do-I-understand-the-tmux-design-architecture-and-internals

https://unix.stackexchange.com/questions/117981/what-are-the-responsibilities-of-each-pseudo-terminal-pty-component-software