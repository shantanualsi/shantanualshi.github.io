---
id: 483
title: The science behind motivation
date: 2017-10-06T23:59:21+08:00
author: shantanualshi
layout: post
guid: http://blog.shantanualshi.com/?p=483
permalink: /?p=483
categories:
  - Uncategorized
---
Bob is a

The striatum is a group of cortical structures consisting of putamen, caudate and nucleus acumbens. The ventral striatum consists of nucleus acumbens that is a part of the brains reward system.

&nbsp;

https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3449003/

https://www.neuroscientificallychallenged.com/blog/know-your-brain-reward-system

https://www.neuroscientificallychallenged.com/blog/know-your-brain-striatum

http://cshperspectives.cshlp.org/content/7/8/a021691.full

http://mashable.com/2017/06/27/the-neuroscience-of-motivation/#Jx4NbgpMKaqn